<?php

use App\models\User;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\data\ActiveDataProvider;
use yii\widgets\Pjax;

$this->title = 'User';
$this->params['breadcrumbs'][] = $this->title;

$user = Yii::$app->user->identity;
if($user !== null){
    $dataProvider = new ActiveDataProvider([
        'query' => User::find(),
        'pagination' => [
            'pageSize' => 10,
        ],
    ]);
}else{
    $dataProvider = new ActiveDataProvider([
        'query' => User::find()->where(['id' => $user->id]),
    ]);

}

?>

<div>
    <h1>
        <?=  Html::encode($this->title)  ?>
    </h1>

    <p>
        <?=  Html::a('Create User', ['create'], ['class' => 'btn btn-primary'])  ?>
    </p>
</div>

<?php Pjax::begin(); ?>

<?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'name',
            'username',
            'email',
            'password', 
            'role',
            [
                'class' => 'yii\grid\ActionColumn',
                'visibleButtons' => [
                    'view' => true,
                    'update' => true,
                    'delete'=>function ($data) {
                        if(Yii::$app->user->id != $data->id && $data->role != 'ADMIN'){

                            return Html::a('', 'delete', ['class' => 'delete']);
                        }
                    },
                        
                ]
            ],
        ]
    ]);
    
?> 
<?php Pjax::end(); ?>