<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Employee Form';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="enquiry-form">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="alert alert-success">
            <?= Yii::$app->session->getFlash('success') ?>
        </div>
    <?php endif; ?>
        <?php   $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>
        <?= $form->field($model, 'name') ?>
        <?= $form->field($model, 'email') ?>
        <?= $form->field($model, 'phone') ?>
        <?= $form->field($model, 'gender') ?>
        <?= $form->field($model, 'status') ?>
        <?= $form->field($model, 'h_date')->input('date') ?>
        <?= $form->field($model, 'dob')->input('date') ?>
        <?= $form->field($model, 'salary') ?>
        <?= $form->field($model, 'address') ?>
        <?= $form->field($model, 'city') ?>
        <?= $form->field($model, 'pincode') ?>
        <?= $form->field($model, 'hobbies')->textarea(['rows' => 4]) ?>
        <?= $form->field($model, 'image')->fileInput() ?>

        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>

        <?php ActiveForm::end(); ?>
</div>

